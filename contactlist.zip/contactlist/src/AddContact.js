import { Button } from "@mui/material";
import React from "react";
import { useNavigate } from "react-router";
import "./styles.css";
import { useForm } from "react-hook-form";

const required = "This field is required";
const maxLength = "Your input exceed maximum length";

// Error Component
const errorMessage = (error) => {
  return <div className="invalid-feedback">{error}</div>;
};
const AddContact = () => {
  const nav = useNavigate();
  const { handleSubmit, errors } = useForm();
  const onSubmit = (data) => console.log(data);
  return (
    <div>
      <Button onClick={() => nav("/")} variant="contained">
        Back
      </Button>
      <div className="container">
        <div className="col-sm-12">
          <h3>Add Contact</h3>
        </div>
        <div className="col-sm-12">
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="form-group">
              <input
                className="form-control"
                type="text"
                placeholder="FirstName"
                name="firstname"
                // ref={register({ required: true, maxLength: 20 })}
              />
              {/* {errors.Username &&
                errors.Username.type === "required" &&
                errorMessage(required)}
              {errors.Username &&
                errors.Username.type === "maxLength" &&
                errorMessage(maxLength)} */}
            </div>
            <div className="form-group">
              <input
                className="form-control"
                type="text"
                placeholder="LastName"
                name="last"
                // ref={register({ required: true, maxLength: 20 })}
              />
              {/* {errors.Username &&
                errors.Username.type === "required" &&
                errorMessage(required)}
              {errors.Username &&
                errors.Username.type === "maxLength" &&
                errorMessage(maxLength)} */}
            </div>
            <div className="form-group">
              <input
                className="form-control"
                type="text"
                placeholder="Email"
                name="email"
                // ref={register({ required: true, maxLength: 50 })}
              />
              {/* {errors.Name &&
                errors.Name.type === "required" &&
                errorMessage(required)}
              {errors.Name &&
                errors.Name.type === "maxLength" &&
                errorMessage(maxLength)} */}
            </div>
            <div className="form-group">
              <input
                className="form-control"
                type="file"
                placeholder="Image"
                name="image"
                // ref={register({ required: true, maxLength: 50 })}
              />
              {/* {errors.Name &&
                errors.Name.type === "required" &&
                errorMessage(required)}
              {errors.Name &&
                errors.Name.type === "maxLength" &&
                errorMessage(maxLength)} */}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddContact;
