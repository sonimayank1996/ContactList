export const simpleAction = (obj)  => {
    return {
     type: 'SIMPLE_ACTION',
     payload: obj
    }
   }