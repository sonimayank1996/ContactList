import React, { useEffect, useState } from "react";
import { simpleAction } from "./redux/actions/simpleActions";
import { useDispatch, useSelector } from "react-redux";
import Card from "@mui/material/Card";
import CardHeader from "@mui/material/CardHeader";
import Avatar from "@mui/material/Avatar";
import {
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
} from "@mui/material";
import { AiFillDelete } from "react-icons/ai";
import { useNavigate } from "react-router";

const Home = () => {
  // console.log("object", statesArray);
  const dispatch = useDispatch();
  const [contact, setContact] = useState("");
  const nav = useNavigate();
  useEffect(() => {
    async function fetchData() {
      try {
        const contactList = await fetch(`https://reqres.in/api/users`);
        const json = await contactList.json();
        dispatch(simpleAction(json.data));
        console.log("json", json);
      } catch (e) {
        console.error(e);
      }
    }
    fetchData();
  }, []);
  const statesArray = useSelector((state) => state.simple.userData);
  console.log("state", statesArray);

  const deleteIcon = (id) => {
    // statesArray.splice(id, 1);
    const remainingArr = statesArray.filter((data) => data.id != id);
    dispatch(simpleAction(remainingArr));
  };
  const handleChange = async (event) => {
    setContact(event.target.value);
    if (event.target.value == 20) {
      statesArray.sort(function (a, b) {
        const nameA = a.first_name.toUpperCase(); // ignore upper and lowercase
        const nameB = b.first_name.toUpperCase(); // ignore upper and lowercase
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }
        return 0;
      });
    } else if (event.target.value == 30) {
      statesArray.sort(function (a, b) {
        const nameA = a.first_name.toUpperCase(); // ignore upper and lowercase
        const nameB = b.first_name.toUpperCase(); // ignore upper and lowercase
        if (nameA < nameB) {
          return 1;
        }
        if (nameA > nameB) {
          return -1;
        }
        return 0;
      });
    } else {
      // const contactList = await fetch(`https://reqres.in/api/users`);
      // const json = await contactList.json();
      dispatch(simpleAction(statesArray));
    }
  };
  return (
    <>
      <FormControl style={{ width: "200px", marginTop: "20px" }}>
        <InputLabel id="demo-simple-select-label">All</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={contact}
          label="contact"
          onChange={(e) => handleChange(e)}
        >
          <MenuItem value={10}>All Data</MenuItem>
          <MenuItem value={20}>A-Z</MenuItem>
          <MenuItem value={30}>Z-A</MenuItem>
          {/* <MenuItem value={30}>Thirty</MenuItem> */}
        </Select>
      </FormControl>
      <Button
        variant="contained"
        onClick={() => nav("/add-contact")}
        style={{ marginTop: "20px", marginLeft: "200px" }}
      >
        Add Contact
      </Button>
      <div style={{ marginLeft: "33%" }}>
        {statesArray &&
          statesArray.map((ele, i) => {
            return (
              <Card
                key={i}
                sx={{ maxWidth: 345, margin: "10px", alignItems: "center" }}
              >
                <CardHeader
                  avatar={<Avatar alt="Remy Sharp" src={`${ele.avatar}`} />}
                  title={`${ele.first_name} ${ele.last_name}`}
                  subheader={`${ele.email}`}
                />
                <AiFillDelete onClick={() => deleteIcon(ele.id)} />
              </Card>
            );
          })}
      </div>
    </>
  );
};

export default Home;
